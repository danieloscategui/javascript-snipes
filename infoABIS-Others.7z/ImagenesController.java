package pe.gob.reniec.abioweb.logic.web.controller;

import com.itextpdf.text.pdf.BarcodeQRCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import pe.gob.reniec.abioweb.logic.model.RegistroConsulta;
import pe.gob.reniec.abioweb.logic.model.Usuario;
import pe.gob.reniec.abioweb.logic.service.RegistroConsultaService;
import pe.gob.reniec.abioweb.logic.web.util.ApplicationProperties;
import pe.gob.reniec.commons.ciudadano.logic.service.CiudadanoService;
import pe.gob.reniec.commons.datautils.DataValidation;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Creado por: Victor Dino Flores Belizario
 * vflores@reniec.gob.pe
 * Date: 25/07/13
 * Time: 10:24 AM
 */
@Controller
@RequestMapping(value = "/imagenes")
public class ImagenesController {

	@Autowired
	CiudadanoService consultaService;

	@Autowired
	Usuario usuario;

	@Autowired
	RegistroConsultaService registroConsultaService;

	@Autowired
	ApplicationProperties applicationProperties;

	@ResponseBody
	@RequestMapping(value="/fotousuario.do", method= RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] fotoUsuario(){
		return consultaService.getFotoCiudadano(usuario.getNuDocumento());
	}

	@ResponseBody
	@RequestMapping(value = "/fotociudadano.do", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] fotoCiudadano(
					@RequestParam(value = "nuDni", required = false) String nuDni,
					@RequestParam(value="token", required=false)String codigoRegistroLog
	) {
		if (DataValidation.isEmptyOrNull(nuDni)||DataValidation.isEmptyOrNull(codigoRegistroLog)) {
			return new byte[0];
		}
		RegistroConsulta registroConsulta = registroConsultaService.obtenerRegistroConsulta(codigoRegistroLog, nuDni);
		if(registroConsulta==null){
			return new byte[0];
		}
		String institucion = "RENIEC © " + registroConsulta.getAnioConsulta();
		return consultaService.getFotoCiudadanoEntramado(nuDni, usuario.getNuDocumento(), institucion, usuario.getDeRazonSocial(), registroConsulta.getFeConsulta());
	}

	private String getHashUserName(String userName){
		String[] words=userName.split("\\s+");
		StringBuilder sb=new StringBuilder();
		for(String word:words){
			sb.append(word.charAt(0));
		}
		return sb.toString();
	}

	@ResponseBody
	@RequestMapping(value = "/qrcode.do", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] qrcode(Model model, HttpServletRequest request, @RequestParam(value="nuDni", required=false)String nuDni, @RequestParam(value="coRegistro", required=false)String coRegistro) {
		if(!DataValidation.isNuDni(nuDni)||DataValidation.isEmptyOrNull(coRegistro)) {
			return new byte[0];
		}
		String url=applicationProperties.getVerificationUrl()+"?nuDni="+nuDni+"&coVerificacion="+coRegistro;
		BarcodeQRCode qrcode = new BarcodeQRCode(url, 100, 100, null);
		try {
			Image image = qrcode.createAwtImage(Color.BLACK, Color.WHITE);
			ByteArrayOutputStream baos =new ByteArrayOutputStream();
			BufferedImage bi=new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_BGR);
			bi.getGraphics().drawImage(image, 0, 0, null);
			ImageIO.write(bi, "jpg", baos);
			byte[] result=baos.toByteArray();
			baos.flush();
			baos.close();
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new byte[0];
	}

	/*@ResponseBody
	@RequestMapping(value = "/firmaciudadano.do", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] firmaCiudadano(@RequestParam(value = "nuForm", required = false) String nuForm) {
		if (nuForm != null && !nuForm.isEmpty()) {
			return consultaService.getFirmaCiudadano(nuForm);
		} else {
			return new byte[0];
		}
	}

	@ResponseBody
	@RequestMapping(value = "/huelladerechaciudadano.do", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] huellaDerechaCiudadano(@RequestParam(value = "nuForm", required = false) String nuForm) {
		if (nuForm != null && !nuForm.isEmpty()) {
			return consultaService.getHuellaDerechaCiudadano(nuForm);
		} else {
			return new byte[0];
		}
	}

	@ResponseBody
	@RequestMapping(value = "/huellaizquierdaciudadano.do", method = RequestMethod.GET, produces = MediaType.IMAGE_JPEG_VALUE)
	public byte[] huellaIzquierdaCiudadano(@RequestParam(value = "nuForm", required = false) String nuForm) {
		if (nuForm != null && !nuForm.isEmpty()) {
			return consultaService.getHuellaDerechaCiudadano(nuForm);
		} else {
			return new byte[0];
		}
	}*/

}
