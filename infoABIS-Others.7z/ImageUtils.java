package pe.gob.reniec.commons.ciudadano.logic.utils;

import org.springframework.stereotype.Component;

import javax.imageio.ImageIO;
import javax.media.	jai.JAI;
import javax.media.jai.PlanarImage;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.awt.image.renderable.ParameterBlock;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Creado por: Victor Dino Flores Belizario
 * vflores@reniec.gob.pe
 * Date: 28/01/14
 * Time: 09:18 AM
 */
@Component
public class ImageUtils {

	private List<String> getImageTextLines(FontMetrics fm, String phrase, int width) {
		List<String> result = new ArrayList<String>();

		String[] words = phrase.trim().split("\\s+");
		//*System.out.println(Arrays.toString(words));
		String tempText = "";
		String currentText = "";
		for (String word : words) {
			tempText += (currentText.isEmpty() ? "" : " ") + word;
			if (width < fm.stringWidth(tempText)) {
				if (currentText.isEmpty()) {
					//es una plabra que se desborda, dibujar tempText
					result.add(tempText);
					//*System.out.println(tempText);
					currentText = "";
					tempText = "";
				} else {
					//dibujar currentText
					result.add(currentText);
					//*System.out.println(currentText);
					currentText = word;
					tempText = word;
				}
			} else {
				currentText = tempText;
			}
		}
		if (!currentText.isEmpty()) {
			result.add(currentText);
			//*System.out.println(currentText);
		}
		return result;
	}

	public byte[] entramarFotoAlt(byte[] imageInByte, String usuario, String institucion, String organizacion, String fecha) throws IOException {
		InputStream in = new ByteArrayInputStream(imageInByte);
		BufferedImage bufferedImage = ImageIO.read(in);
		Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
		//g2d.drawImage(photo.getImage(), 0, 0, null);
		int iAncho = bufferedImage.getWidth();
		int iAlto = bufferedImage.getHeight();


		//Create an alpha composite of 50%
		AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.40f);
		g2d.setComposite(alpha);
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		// Empresa
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif", Font.BOLD, 15));
		FontMetrics fm = g2d.getFontMetrics();
		List<String> lines = getImageTextLines(fm, organizacion, iAncho);
		float yText=25;
		float heightText=fm.getAscent();
		for (String text : lines) {
			float xText = (iAncho - fm.stringWidth(text)) / 2;
			g2d.drawString(text, xText, yText);
			yText+=heightText;
		}

		// Fecha - Hora
		g2d.rotate(Math.PI / 2.0);
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 15));
		g2d.drawString(fecha, (iAlto-fm.stringWidth(fecha))*2/3, - iAncho + 15);
		g2d.drawString(institucion, (iAlto-fm.stringWidth(institucion))*2/3, -7);

		g2d.rotate(-1 * Math.PI);
		// Logo
		g2d.rotate(Math.PI * 0.80);
		g2d.setPaint(Color.LIGHT_GRAY);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 30));
		//g2d.drawString(institucion, 40, 20);
		g2d.drawString(usuario, 75, 5);

		//double angle=Math.PI*0.80;

		//usuario="YOOOOOOOOOO NI SE";
		// Usuario
		/*g2d.setPaint(Color.darkGray);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 20));
		fm=g2d.getFontMetrics();

		int _x=iAncho/2;
		int _y=iAlto/2;
		angle+=-1 * Math.PI / 2.0;
		int x = (int) (_x * Math.cos(angle) + _y * Math.sin(angle));
		int y = (int) (-_x * Math.sin(angle) + _y * Math.cos(angle));
		//System.out.println(x+" "+y);
		g2d.drawString(usuario, x-fm.stringWidth(usuario)/2, y+40);*/

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", baos);
		baos.flush();
		byte[] returnImage = baos.toByteArray();
		baos.close();
		return returnImage;
	}

	/*
	public byte[] entramarFoto(byte[] imageInByte, String usuario, String institucion, String organizacion, String fecha) throws IOException {
		InputStream in = new ByteArrayInputStream(imageInByte);
		BufferedImage bufferedImage = ImageIO.read(in);
		Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
		//g2d.drawImage(photo.getImage(), 0, 0, null);
		int iAncho = bufferedImage.getWidth();
		int iAlto = bufferedImage.getHeight();


		//Create an alpha composite of 50%
		AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.40f);
		g2d.setComposite(alpha);
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		// Empresa
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif", Font.BOLD, 20));
		FontMetrics fm = g2d.getFontMetrics();
		List<String> lines = getImageTextLines(fm, organizacion, iAncho);
		float yText=25;
		float heightText=fm.getAscent();
		for (String text : lines) {
			float xText = (iAncho - fm.stringWidth(text)) / 2;
			g2d.drawString(text, xText, yText);
			yText+=heightText;
		}

		// Fecha - Hora
		g2d.rotate(-1 * Math.PI / 2.0);
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 20));
		g2d.drawString(fecha, -220, iAncho - 7);

		// Logo
		g2d.rotate(Math.PI * 0.80);
		g2d.setPaint(Color.LIGHT_GRAY);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 30));
		g2d.drawString(institucion, 40, 20);

		double angle=Math.PI*0.80;

		//usuario="YOOOOOOOOOO NI SE";
		// Usuario
		g2d.setPaint(Color.darkGray);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 20));
		fm=g2d.getFontMetrics();

		int _x=iAncho/2;
		int _y=iAlto/2;
		angle+=-1 * Math.PI / 2.0;
		int x = (int) (_x * Math.cos(angle) + _y * Math.sin(angle));
		int y = (int) (-_x * Math.sin(angle) + _y * Math.cos(angle));
		//System.out.println(x+" "+y);
		g2d.drawString(usuario, x-fm.stringWidth(usuario)/2, y+40);

		/*g2d.setColor(Color.white);
		g2d.drawLine(0, 0, 100, 0);
		g2d.setColor(Color.green);
		g2d.drawLine(0, 0, 0, 100);

		g2d.setColor(Color.red);
		g2d.drawRect(10, 10, x, y);*/

		/*float cato=(float)Math.abs(Math.sin(angle)*fm.stringWidth(usuario));
		float top=(iAlto-cato)/2;

		float cata=(float)Math.abs(Math.cos(angle)*fm.stringWidth(usuario));
		float posIniUsuario = (iAncho - cata) / 2;//+(float)Math.sin(Math.PI * 0.80)*top;
		//System.out.println(cat+" "+iAncho+" "+posIniUsuario);
		int y=(int)(posIniUsuario*Math.cos(angle)+top*Math.sin(angle));
		int x=(int)(-posIniUsuario*Math.sin(angle)+top*Math.cos(angle))-fm.stringWidth(usuario)/2;
		System.out.println(posIniUsuario+" "+top);
		System.out.println(x+" "+y);
		g2d.drawString(usuario, x, y);
		g2d.setColor(Color.red);
		g2d.drawRect(0, 0, x, y);* /


		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", baos);
		baos.flush();
		byte[] returnImage = baos.toByteArray();
		baos.close();
		return returnImage;
	}

	public byte[] _entramarFoto(byte[] imageInByte, String usuario, String institucion, String organizacion, String fecha) throws IOException {
		InputStream in = new ByteArrayInputStream(imageInByte);
		BufferedImage bufferedImage = ImageIO.read(in);
		Graphics2D g2d = (Graphics2D) bufferedImage.getGraphics();
		//g2d.drawImage(photo.getImage(), 0, 0, null);
		int iAncho = bufferedImage.getWidth();
		int iAlto = bufferedImage.getHeight();


		//Create an alpha composite of 50%
		AlphaComposite alpha = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.40f);
		g2d.setComposite(alpha);
		g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		// Empresa
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif", Font.BOLD, 20));
		float lonCharEmpresa = iAncho / 15;
		float posIniEmpresa = (iAncho - lonCharEmpresa * organizacion.length()) / 2;
		g2d.drawString(organizacion, posIniEmpresa, 25);


		// Fecha - Hora
		g2d.rotate(-1 * Math.PI / 2.0);
		g2d.setPaint(Color.BLACK);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 20));
		g2d.drawString(fecha, -230, iAncho - 15);

		// Logo
		g2d.rotate(Math.PI * 0.80);
		g2d.setPaint(Color.LIGHT_GRAY);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 30));
		g2d.drawString(institucion, 45, 20);

		// Usuario
		g2d.setPaint(Color.darkGray);
		g2d.setFont(new Font("SansSerif ", Font.BOLD, 20));
		float lonCharUsuario = 510 / 25;
		float posIniUsuario = (510 - lonCharUsuario * usuario.length()) / 2;
		g2d.drawString(usuario, posIniUsuario, 60);

		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(bufferedImage, "jpg", baos);
		baos.flush();
		byte[] returnImage = baos.toByteArray();
		baos.close();
		return returnImage;
	}

	public byte[] tiffToJpeg(byte[] bytes) {
		try {
			ParameterBlock params = new ParameterBlock();
			ByteArraySeekableStream bass = new ByteArraySeekableStream(bytes); //<-- byte[] TIFF de la base de datos o de la inagen del FileSystem
			params.add(bass);
			TIFFDecodeParam decodeParam = new TIFFDecodeParam();
			decodeParam.setDecodePaletteAsShorts(true);
			ImageDecoder decoder = ImageCodec.createImageDecoder("tiff", bass, decodeParam);
			RenderedImage ri = decoder.decodeAsRenderedImage();
			bass.close();
			int bitsPerPixel = ri.getColorModel().getPixelSize();
			//ri.getColorModel().getColorSpace().getType();
			if (bitsPerPixel > 1 && ri.getColorModel().getColorSpace().getType() != 6) {
				PlanarImage imgG = convertGrayScale(ri);
				ri = (RenderedImage) imgG.createSnapshot();
				imgG.dispose();
			}


			ByteArrayOutputStream rb = null;
			OutputStream oss = new ByteArrayOutputStream();

			PNGEncodeParam pngParam = PNGEncodeParam.getDefaultEncodeParam(ri);
			pngParam.setBitDepth(1);

			PNGImageEncoder encoder = new PNGImageEncoder(oss, pngParam);
			encoder.encode(ri);
			rb = (ByteArrayOutputStream) oss;
			oss.close();

			return rb.toByteArray();// <-- byte[] JPEG, lo mostramos con el output de un servlet
		} catch (Exception e) {
			e.printStackTrace();
			return null;

		}
	}
	*/

	public PlanarImage convertGrayScale(RenderedImage img) {
		double[][] matrix = {{0.3D, 0.59D, 0.11D, 0D}};
		ParameterBlock pb = new ParameterBlock();
		pb.addSource(img);
		pb.add(matrix);
		PlanarImage result = JAI.create("BandCombine", pb, null);
		return result;
	}

}
