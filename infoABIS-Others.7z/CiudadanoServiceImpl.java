package pe.gob.reniec.commons.ciudadano.logic.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.gob.reniec.commons.ciudadano.logic.dao.CiudadanoDao;
import pe.gob.reniec.commons.ciudadano.logic.model.Ciudadano;
import pe.gob.reniec.commons.ciudadano.logic.model.Dedos;
import pe.gob.reniec.commons.ciudadano.logic.model.Restriccion;
import pe.gob.reniec.commons.ciudadano.logic.service.CiudadanoService;
import pe.gob.reniec.commons.ciudadano.logic.utils.ImageUtils;

import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: crosales
 * Date: 14/11/13
 * Time: 10:58 AM
 * To change this template use File | Settings | File Templates.
 */

@Service
public class CiudadanoServiceImpl implements CiudadanoService {

	private static Logger logger = Logger.getLogger(CiudadanoServiceImpl.class);

	@Autowired
	private CiudadanoDao ciudadanoDao;

	@Autowired
	ImageUtils imageUtils;

	//validaDNI helpers
	private boolean tieneDobleInscripcion(String coGrupoRestri, String coRestri) {
		return coGrupoRestri.equals("21") && (coRestri.equals("01") || coRestri.equals("D"));
	}

	private boolean esFallecido(String coGrupoRestri, String coRestri) {
		return coGrupoRestri.equals("21") && (coRestri.equals("04") ||
						coRestri.equals("-") ||
						coRestri.equals("$") ||
						coRestri.equals("A") ||
						coRestri.equals("!"));
	}

	private boolean noTieneDedos(String coDedoDerecho, String coDedoIzquierdo) {
		return coDedoDerecho.equals("11") && coDedoIzquierdo.equals("11");
	}

	@Override
	public Dedos consultarDedos(String nuDni) throws Exception {
		return ciudadanoDao.queryDedos(nuDni);
	}

	@Override
	public boolean consultaSiTieneHuellas(String nuDni) {
		return ciudadanoDao.consultaSiTieneHuellas(nuDni);
	}

	@Override
	public Ciudadano obtenerDatosCiudadano(String nuDni) throws Exception {
		return ciudadanoDao.performQueryByDni(nuDni);
	}

	@Override
	public byte[] getFotoCiudadano(String nuDni) {
		return ciudadanoDao.getFotoCiudadano(nuDni);
	}

	@Override
	public byte[] getFotoCiudadanoEntramado(String nuDni, String usuario, String institucion, String organizacion, String fecha) {
		byte[] img = ciudadanoDao.getFotoCiudadano(nuDni);
		if (img != null) {
			try {
				return imageUtils.entramarFotoAlt(img, usuario, institucion, organizacion, fecha);
			} catch (IOException e) {
				e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
			}
		}
		return img;
	}

	@Override
	public Restriccion verificaRestriccion(String nuDni) throws Exception {
		return ciudadanoDao.verificaRestriccion(nuDni);
	}

}
